import "./App.css";

function App() {
  return(
  <>
    SpringBoot와 React 연동하기
  </>
  )
}

export default App;
